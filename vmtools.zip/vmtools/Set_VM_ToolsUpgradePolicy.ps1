$vmlist=Get-Content -Path J:\Navaneeth\vmtools\mulVMsListBulk.txt
$vms = Get-VM -Name $vmlist

Foreach ($VM in $vms) {
$VMConfig = Get-View -VIObject $VM.Name
$vmConfigSpec = New-Object VMware.Vim.VirtualMachineConfigSpec
$vmConfigSpec.Tools = New-Object VMware.Vim.ToolsConfigInfo
#$vmConfigSpec.Tools.ToolsUpgradePolicy = "manual"
vmConfigSpec.Tools.ToolsUpgradePolicy = "UpgradeAtPowerCycle"
$VMConfig.ReconfigVM($vmConfigSpec)
}