$vmlist2=Get-Content -Path J:\Navaneeth\vmtools\mulVMsListBulk.txt
$vms = Get-VM -Name $vmlist2
foreach($VM in $vms){
Get-VM $VM |  % { get-view $_.id } | select name   , @{Name=�ToolsVersion�; Expression={$_.config.tools.toolsversion}}, @{ Name=�ToolStatus�; Expression={$_.Guest.ToolsVersionStatus}}, @{N='ToolsUpgradePolicy';E={$_.Config.Tools.ToolsUpgradePolicy } }
}