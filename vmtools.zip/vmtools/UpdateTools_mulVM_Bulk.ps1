﻿# Get the list of VM names from the text file
$vmlist = Get-Content -Path "J:\Navaneeth\vmtools\mulVMsListBulk.txt"

# Get the VM objects
$vms = Get-VM -Name $vmlist

# Create an array to store update tasks
$tasks = @()

# Loop through each VM and start updating VMware Tools
foreach ($VM in $vms) {
    $task = Update-Tools -VM $VM -NoReboot -RunAsync
    $tasks += $task
}

# Monitor the progress of update tasks
$completedTasks = $tasks | Where-Object { $_.IsComplete -eq $true }

# Wait for all update tasks to complete
while ($completedTasks.Count -lt $tasks.Count) {
    Write-Host "Updating VMware Tools..."
    Start-Sleep -Seconds 10  # Adjust the sleep interval as needed
    $completedTasks = $tasks | Where-Object { $_.IsComplete -eq $true }
}

Write-Host "VMware Tools update completed for all VMs."
