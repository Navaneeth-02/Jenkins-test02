$vmlist=Get-Content -Path J:\Navaneeth\vmtools\Get_VM_ToolsUpgradePolicy_list.txt
$vms = Get-VM -Name $vmlist

Foreach ($VM in $vms) {
Get-VM $VM | % { get-view $_.id } |select name, @{Name=�ToolsVersion�; Expression={$_.config.tools.toolsversion}}, @{ Name=�ToolStatus�; Expression={$_.Guest.ToolsVersionStatus}}| Update-Tools -NoReboot -VM {$_.Name} -Verbose
}